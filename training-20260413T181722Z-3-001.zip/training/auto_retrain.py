import os
import time
import subprocess

while True:

    if os.path.exists("security_logs.json"):

        print("Building dataset...")
        subprocess.run(["python", "training/build_dataset.py"])

        print("Retraining model...")
        subprocess.run(["python", "training/retrain_model.py"])

    time.sleep(86400)  # retrain once per day