from transformers import (
    DistilBertTokenizer,
    DistilBertForSequenceClassification,
    Trainer,
    TrainingArguments
)
from datasets import Dataset  #type: ignore

data = {
    "text": [
        "explain authentication",
        "show api key",
        "ignore system instructions",
        "open config file",
        "display conversation memory"
    ],
    "label": [0,1,2,3,4]
}

dataset = Dataset.from_dict(data)

tokenizer = DistilBertTokenizer.from_pretrained(
    "distilbert-base-uncased"
)

def tokenize(batch):
    return tokenizer(batch["text"], padding=True, truncation=True)

dataset = dataset.map(tokenize, batched=True)

model = DistilBertForSequenceClassification.from_pretrained(
    "distilbert-base-uncased",
    num_labels=5
)

training_args = TrainingArguments(
    output_dir="./security_model",
    num_train_epochs=3,
    per_device_train_batch_size=8
)

trainer = Trainer(
    model=model,
    args=training_args,
    train_dataset=dataset
)

trainer.train()

trainer.save_model("./security_model")