from transformers import (
    DistilBertTokenizer,
    DistilBertForSequenceClassification,
    Trainer,
    TrainingArguments
)
from datasets import load_dataset #type: ignore

dataset = load_dataset("json", data_files="security_training_data.json")

tokenizer = DistilBertTokenizer.from_pretrained(
    "distilbert-base-uncased"
)

def tokenize(example):
    return tokenizer(example["text"], truncation=True, padding=True)

dataset = dataset.map(tokenize)

model = DistilBertForSequenceClassification.from_pretrained(
    "distilbert-base-uncased",
    num_labels=5
)

training_args = TrainingArguments(
    output_dir="./security_model",
    num_train_epochs=2,
    per_device_train_batch_size=8
)

trainer = Trainer(
    model=model,
    args=training_args,
    train_dataset=dataset["train"]
)

trainer.train()

trainer.save_model("./security_model")