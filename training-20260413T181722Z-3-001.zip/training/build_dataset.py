import json

LOG_FILE = "security_logs.json"
OUTPUT_FILE = "security_training_data.json"


def build_dataset():

    dataset = []

    with open(LOG_FILE) as f:

        for line in f:

            record = json.loads(line)

            dataset.append({
                "text": record["prompt"],
                "label": record["category"]
            })

    with open(OUTPUT_FILE, "w") as f:
        json.dump(dataset, f, indent=2)


if __name__ == "__main__":
    build_dataset()