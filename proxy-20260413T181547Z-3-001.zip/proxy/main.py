from fastapi import FastAPI
from pydantic import BaseModel
import httpx
import yaml

from Sentinel.intent_detector import detect_intent
from Sentinel.injection_detector import detect_prompt_injection
from Sentinel.dlp_scanner import scan
from Sentinel.memory_firewall import scan_memory, detect_memory_access
from Sentinel.output_filter import filter_output
from Sentinel.logger import log_event
from Sentinel.risk_engine import calculate
from Sentinel.conversation_monitor import add_prompt, detect_conversation_attack


app = FastAPI(title="SentinelAI Security Proxy")

MCP_URL = "http://127.0.0.1:9000"

# ---------------------------------------------------
# Load Security Policy
# ---------------------------------------------------

with open("proxy/policy.yaml") as f:
    policy = yaml.safe_load(f)

ALLOWED_TOOLS = policy.get("allowed_tools", [])
BLOCKED_TOOLS = policy.get("blocked_tools", [])


class ProxyRequest(BaseModel):
    agent: str
    prompt: str
    tool: str
    args: str
    memory: list | None = None


# ---------------------------------------------------
# Proxy Endpoint
# ---------------------------------------------------

@app.post("/proxy/tool_call")
def proxy_call(req: ProxyRequest):

    prompt = req.prompt
    tool = req.tool
    args = req.args
    memory = req.memory or []

    content = f"{prompt} {args}"

    # ---------------------------------------------------
    # Conversation Monitoring
    # ---------------------------------------------------

    add_prompt(prompt)
    conversation_risk = detect_conversation_attack()

    # ---------------------------------------------------
    # Policy Enforcement
    # ---------------------------------------------------

    if tool in BLOCKED_TOOLS:

        log_event(prompt, tool, "blocked_policy", 90)

        return {
            "status": "blocked",
            "reason": "tool_blocked_by_policy"
        }

    if tool not in ALLOWED_TOOLS:

        log_event(prompt, tool, "blocked_unknown_tool", 90)

        return {
            "status": "blocked",
            "reason": "tool_not_allowed"
        }

    # ---------------------------------------------------
    # Intent Detection
    # ---------------------------------------------------

    intent = detect_intent(content)
    intent_risk = intent.get("risk", 0)

    # ---------------------------------------------------
    # Prompt Injection Detection
    # ---------------------------------------------------

    injection = detect_prompt_injection(content)
    injection_risk = injection.get("risk", 0)

    # ---------------------------------------------------
    # DLP Scan
    # ---------------------------------------------------

    dlp = scan(content)
    dlp_risk = dlp.get("risk", 0)

    # ---------------------------------------------------
    # Memory Firewall
    # ---------------------------------------------------

    memory_scan = scan_memory(memory)
    memory_risk = memory_scan.get("risk", 0)

    memory_access = detect_memory_access(prompt)
    memory_access_risk = memory_access.get("risk", 0)

    # ---------------------------------------------------
    # Risk Engine (still computed for logging)
    # ---------------------------------------------------

    risk = calculate(
        intent_risk,
        injection_risk,
        dlp_risk,
        memory_risk + memory_access_risk,
        conversation_risk,
        tool
    )

    # ---------------------------------------------------
    # DEBUG (optional but useful)
    # ---------------------------------------------------

    print("\n--- Sentinel Proxy Security Report ---")
    print("Intent Risk:", intent_risk)
    print("Injection Risk:", injection_risk)
    print("DLP Risk:", dlp_risk)
    print("Memory Risk:", memory_risk)
    print("Memory Access Risk:", memory_access_risk)
    print("Conversation Risk:", conversation_risk)
    print("Total Risk:", risk)
    print("--------------------------------------")

    # ---------------------------------------------------
    # PRIORITY SECURITY DECISION
    # ---------------------------------------------------

    # Prompt injection → immediate block
    if injection_risk >= 50:

        log_event(prompt, tool, "blocked_prompt_injection", injection_risk)

        return {
            "status": "blocked",
            "reason": "prompt_injection_detected",
            "risk": injection_risk
        }

    # Sensitive data leakage
    if dlp_risk >= 50:

        log_event(prompt, tool, "blocked_data_exfiltration", dlp_risk)

        return {
            "status": "blocked",
            "reason": "data_exfiltration_detected",
            "risk": dlp_risk
        }

    # Memory extraction attempt
    if memory_access_risk >= 50:

        log_event(prompt, tool, "blocked_memory_access", memory_access_risk)

        return {
            "status": "blocked",
            "reason": "memory_access_detected",
            "risk": memory_access_risk
        }

    # Conversation attack pattern
    if conversation_risk >= 60:

        log_event(prompt, tool, "blocked_conversation_attack", conversation_risk)

        return {
            "status": "blocked",
            "reason": "conversation_attack_detected",
            "risk": conversation_risk
        }

    # ---------------------------------------------------
    # Forward Tool Request
    # ---------------------------------------------------

    try:

        response = httpx.post(
            f"{MCP_URL}/{tool}",
            json={"args": args},
            timeout=60
        )

        try:
            result = response.json()

        except Exception:

            return {
                "status": "error",
                "message": "Tool returned invalid response"
            }

        # ---------------------------------------------------
        # Output Filtering
        # ---------------------------------------------------

        output_check = filter_output(result)

        if output_check.get("blocked"):

            log_event(prompt, tool, "blocked_output", 90)

            return {
                "status": "blocked",
                "reason": "sensitive_output_detected"
            }

        log_event(prompt, tool, "allowed", risk)

        return result

    except httpx.RequestError as e:

        log_event(prompt, tool, "tool_error", 100)

        return {
            "status": "error",
            "message": str(e)
        }