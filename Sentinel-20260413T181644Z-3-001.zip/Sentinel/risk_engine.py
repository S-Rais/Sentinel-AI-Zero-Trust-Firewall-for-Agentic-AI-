def calculate(intent_risk, injection_risk, dlp_risk, memory_risk, conversation_risk, tool):

    tool_risk = 0

    if tool == "filesystem_tool":
        tool_risk = 80

    if tool == "browser_search_tool":
        tool_risk = 10

    if tool == "wikipedia_tool":
        tool_risk = 5

    if tool == "calculator_tool":
        tool_risk = 5

    total = (
        intent_risk +
        injection_risk +
        dlp_risk +
        memory_risk +
        conversation_risk +
        tool_risk
    )

    return total