import re

SENSITIVE_PATTERNS = [
    r"api[_\s]?key",
    r"token",
    r"password",
    r"secret",
    r"credential",
    r"private[_\s]?key",
    r"access[_\s]?key",
    r"auth[_\s]?token"
]


def scan(prompt):

    text = prompt.lower()

    for pattern in SENSITIVE_PATTERNS:

        if re.search(pattern, text):

            return {
                "detected": True,
                "risk": 70,
                "pattern": pattern
            }

    return {
        "detected": False,
        "risk": 0
    }