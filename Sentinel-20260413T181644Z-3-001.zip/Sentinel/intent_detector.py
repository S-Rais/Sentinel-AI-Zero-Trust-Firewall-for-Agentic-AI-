import re

# Patterns that indicate attempts to access local files or system configuration
INTENT_PATTERNS = [
    r"open\s+(the\s+)?file",
    r"read\s+(the\s+)?file",
    r"system\s+file",
    r"local\s+file",
    r"configuration\s+file",
    r"config\s+file",
    r"read\s+(the\s+)?config",
    r"open\s+(the\s+)?config",
    r"access\s+(the\s+)?config",
    r"system\s+configuration",
    r"list\s+(the\s+)?directory",
    r"show\s+(the\s+)?files",
    r"filesystem",
    r"system\s+data",
    r"internal\s+file",
    r"retrieve\s+config"
]


def detect_intent(prompt):

    text = prompt.lower()

    risk = 0
    matches = []

    for pattern in INTENT_PATTERNS:

        if re.search(pattern, text):
            risk += 40
            matches.append(pattern)

    if risk > 0:
        return {
            "malicious": True,
            "risk": risk,
            "matches": matches
        }

    return {
        "malicious": False,
        "risk": 0,
        "matches": []
    }