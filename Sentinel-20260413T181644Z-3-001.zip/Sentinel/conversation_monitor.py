conversation_history = []

MAX_HISTORY = 10


def add_prompt(prompt):

    conversation_history.append(prompt)

    if len(conversation_history) > MAX_HISTORY:
        conversation_history.pop(0)


def detect_conversation_attack():

    combined = " ".join(conversation_history).lower()

    suspicious_patterns = [
        "remember",
        "stored",
        "internal",
        "system data",
        "hidden data",
        "configuration",
        "session data"
    ]

    score = 0

    for word in suspicious_patterns:

        if word in combined:
            score += 10

    return score