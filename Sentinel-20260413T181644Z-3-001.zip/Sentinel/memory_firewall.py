import re

SENSITIVE_MEMORY_PATTERNS = [
    r"api[_\s]?key",
    r"password",
    r"secret",
    r"token",
    r"credential",
    r"auth[_\s]?token",
]
    

def scan_memory(memory_list):
    
    if not isinstance(memory_list, list):
        return {"risk": 0, "findings": []}
    risk = 0
    findings = []

    for item in memory_list:

        # memory item is a dict: {"role": "...", "content": "..."}
        text = str(item.get("content", "")).lower()

        for pattern in SENSITIVE_MEMORY_PATTERNS:

            if re.search(pattern, text):

                risk += 40
                findings.append(text)

    return {
        "risk": risk,
        "findings": findings
    }


MEMORY_ACCESS_PATTERNS = [
    "what do you remember",
    "what information do you have",
    "what data do you store",
    "internal data",
    "stored information",
    "session data",
    "configuration data",
    "system information",
    "hidden data",
    "show memory",
    "summarize memory",
]


def detect_memory_access(prompt):

    text = prompt.lower()

    for pattern in MEMORY_ACCESS_PATTERNS:

        if pattern in text:

            return {
                "access_attempt": True,
                "risk": 40
            }

    return {
        "access_attempt": False,
        "risk": 0
    }