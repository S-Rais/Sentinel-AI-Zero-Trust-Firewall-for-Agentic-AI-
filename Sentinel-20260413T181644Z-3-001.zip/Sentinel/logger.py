import datetime

LOG_FILE = "logs/security.log"


def log_event(prompt, tool, status, risk):

    with open(LOG_FILE, "a") as f:

        f.write(
            f"{datetime.datetime.now()} | {tool} | {risk} | {status} | {prompt}\n"
        )