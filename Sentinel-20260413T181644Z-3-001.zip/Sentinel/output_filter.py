import re

SENSITIVE_PATTERNS = [
    r"sk-[a-zA-Z0-9]{20,}",          # OpenAI-style keys
    r"api[_\s]?key\s*[:=]\s*\S+",    # api key patterns
    r"password\s*[:=]\s*\S+",
    r"token\s*[:=]\s*\S+",
    r"secret\s*[:=]\s*\S+"
]


def filter_output(data):

    text = str(data).lower()

    for pattern in SENSITIVE_PATTERNS:

        if re.search(pattern, text):

            return {
                "blocked": True,
                "pattern": pattern
            }

    return {
        "blocked": False
    }