import httpx

API_KEY = "dc239c7bacec436fa4f55c617fc2ec12"


def extract_topic(query: str):

    ignore_words = ["news", "today", "latest", "show", "give", "about"]

    for w in query.lower().split():

        if w not in ignore_words:
            return w

    return query


def news_tool(args: str):

    topic = extract_topic(args)

    url = "https://newsdata.io/api/1/news"

    params = {
        "apikey": API_KEY,
        "q": topic,
        "language": "en",
        "category": "sports"
    }

    try:

        r = httpx.get(url, params=params, timeout=10)

        data = r.json()

        results = data.get("results")

        # ----------------------------
        # FIX: validate API response
        # ----------------------------

        if not isinstance(results, list):

            return {
                "result": [
                    {
                        "title": "No news found for this query",
                        "source": "NewsData API",
                        "link": ""
                    }
                ]
            }

        articles = []

        for item in results[:5]:

            articles.append({
                "title": item.get("title", "No title"),
                "source": item.get("source_id", "Unknown"),
                "link": item.get("link", "")
            })

        return {"result": articles}

    except Exception as e:

        return {"error": str(e)}