from tavily import TavilyClient
import os
from dotenv import load_dotenv

load_dotenv()

client = TavilyClient(api_key=os.getenv("TAVILY_API_KEY"))


def browser_search(query):

    try:

        response = client.search(
            query=query,
            search_depth="advanced",
            max_results=5
        )

        results = []

        for r in response["results"]:

            title = r.get("title", "")
            content = r.get("content", "")
            url = r.get("url", "")

            results.append(f"{title} - {content} ({url})")

        if results:
            return " ".join(results)

        return "No browser search result found"

    except Exception as e:

        return str(e)