import wikipedia


def wiki_search(query):

    try:

        result = wikipedia.summary(query, sentences=5)

        return result

    except Exception as e:

        return str(e)