import requests
import re


def extract_city(text):
    """
    Extract city name from a natural language query.
    Example:
    'weather of london today' -> london
    """

    text = text.lower()

    match = re.search(r"(?:in|of)\s+([a-z\s]+)", text)

    if match:
        return match.group(1).replace("today", "").strip()

    return text


def weather(query):

    try:

        city = extract_city(query)

        geo = requests.get(
            "https://geocoding-api.open-meteo.com/v1/search",
            params={
                "name": city,
                "count": 1
            }
        ).json()

        if "results" not in geo:
            return "City not found"

        lat = geo["results"][0]["latitude"]
        lon = geo["results"][0]["longitude"]

        weather = requests.get(
            "https://api.open-meteo.com/v1/forecast",
            params={
                "latitude": lat,
                "longitude": lon,
                "current_weather": True
            }
        ).json()

        w = weather["current_weather"]

        return f"Temperature {w['temperature']}°C"

    except Exception as e:

        return str(e)
    