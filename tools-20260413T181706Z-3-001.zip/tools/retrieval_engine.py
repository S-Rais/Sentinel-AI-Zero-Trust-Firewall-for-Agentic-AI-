import httpx

PROXY_URL = "http://127.0.0.1:8000/proxy/tool_call"


def retrieve_documents(query, memory):

    docs = []

    tools = [
        "search_tool",
        "browser_search_tool"
    ]

    for tool in tools:

        request = {
            "agent": "sentinel_agent",
            "prompt": query,
            "tool": tool,
            "args": query,
            "memory": memory
        }

        try:

            response = httpx.post(PROXY_URL, json=request, timeout=60)

            result = response.json()

            if "result" in result and result["result"]:

                docs.append(result["result"])

        except:
            pass

    return docs