from fastapi import FastAPI
from pydantic import BaseModel

from tools.browser_search_tool import browser_search
from tools.wiki_tool import wiki_search
from tools.weather_tool import weather
from tools.news_tool import news_tool

app = FastAPI(title="SentinelAI MCP Server")


class ToolRequest(BaseModel):
    args: str


# ---------------------------------------------------
# Calculator Tool
# ---------------------------------------------------

@app.post("/calculator_tool")
def calculator(req: ToolRequest):

    try:
        result = eval(req.args)
        return {"result": result}

    except Exception as e:
        return {"error": str(e)}


# ---------------------------------------------------
# Wikipedia Tool
# ---------------------------------------------------

@app.post("/wikipedia_tool")
def wikipedia(req: ToolRequest):

    try:
        return {"result": wiki_search(req.args)}

    except Exception as e:
        return {"error": str(e)}


# ---------------------------------------------------
# Browser Search Tool
# ---------------------------------------------------

@app.post("/browser_search_tool")
def browser(req: ToolRequest):

    try:
        return {"result": browser_search(req.args)}

    except Exception as e:
        return {"error": str(e)}


# ---------------------------------------------------
# Weather Tool
# ---------------------------------------------------

@app.post("/weather_tool")
def weather_api(req: ToolRequest):

    try:
        return {"result": weather(req.args)}

    except Exception as e:
        return {"error": str(e)}


# ---------------------------------------------------
# News Tool
# ---------------------------------------------------

@app.post("/news_tool")
def news_api(req: ToolRequest):

    try:

        # IMPORTANT: return tool response directly
        return news_tool(req.args)

    except Exception as e:

        return {"error": str(e)}