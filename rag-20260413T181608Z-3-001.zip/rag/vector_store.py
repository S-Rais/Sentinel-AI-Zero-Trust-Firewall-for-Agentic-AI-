import chromadb #type: ignore
from sentence_transformers import SentenceTransformer

model = SentenceTransformer("all-MiniLM-L6-v2")

client = chromadb.Client()

collection = client.get_or_create_collection("knowledge")


def add_document(text, doc_id):

    emb = model.encode(text).tolist()

    collection.add(
        documents=[text],
        embeddings=[emb],
        ids=[doc_id]
    )


def retrieve(query, top_k=3):

    emb = model.encode(query).tolist()

    results = collection.query(
        query_embeddings=[emb],
        n_results=top_k
    )

    docs = results["documents"][0]

    return docs